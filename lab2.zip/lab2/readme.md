This lab represents the computing the percentage of dinucleotides and trinucleotides. 09.10.2025

<To run the script please type: python labx_x.py>

Contributors: Ugur Kaan, Arhir Tudor 

Arhir Tudor: https://github.com/Taken7345